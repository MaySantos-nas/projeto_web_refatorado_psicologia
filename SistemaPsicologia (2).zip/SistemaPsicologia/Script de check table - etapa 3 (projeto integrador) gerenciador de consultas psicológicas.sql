CHECK TABLE paciente;
CHECK TABLE consulta;
CHECK TABLE internacao;
CHECK TABLE quarto;
CHECK TABLE convenio;

