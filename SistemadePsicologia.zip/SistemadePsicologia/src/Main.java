public class Main {
    public static void main(String[] args) {
        // Inicializa a aplicação mostrando a Tela de Login
        javax.swing.SwingUtilities.invokeLater(() -> {
            new TelaLogin().setVisible(true);
        });
    }
}


