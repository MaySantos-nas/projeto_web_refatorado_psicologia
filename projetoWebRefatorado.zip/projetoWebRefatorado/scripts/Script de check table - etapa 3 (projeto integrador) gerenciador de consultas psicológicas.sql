CHECK TABLE paciente;
CHECK TABLE psicologo;
CHECK TABLE consulta;
CHECK TABLE internacao;
CHECK TABLE quarto;
CHECK TABLE convenio;
CHECK TABLE agendamentos;
CHECK TABLE relatorios;

DESCRIBE Psicologo;





